
async function predictImage(file){
  const form = new FormData();
  form.append('image', file);
  try {
    const resp = await fetch('/api/predict', { method: 'POST', body: form });
    if(!resp.ok){
      const txt = await resp.text();
      throw new Error('Server error: ' + txt);
    }
    const json = await resp.json();
    return json;
  } catch(err){
    return {error: err.message};
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  const fileInput = document.getElementById('file');
  const uploadBtn = document.getElementById('upload-btn');
  const fileName = document.getElementById('file-name');
  const loading = document.getElementById('loading');
  const resultDiv = document.getElementById('result');

  let selectedFile = null;
  fileInput.addEventListener('change', (e)=>{
    selectedFile = e.target.files[0];
    fileName.textContent = selectedFile ? selectedFile.name : '';
  });

  uploadBtn.addEventListener('click', async ()=>{
    resultDiv.style.display='none';
    resultDiv.innerHTML='';
    if(!selectedFile){
      resultDiv.style.display='block';
      resultDiv.textContent='Please select an image first.';
      return;
    }
    loading.style.display='block';
    uploadBtn.disabled=true;
    const data = await predictImage(selectedFile);
    loading.style.display='none';
    uploadBtn.disabled=false;
    if(data.error){
      resultDiv.style.display='block';
      resultDiv.innerHTML = '<strong style="color:#c00">Error:</strong> ' + data.error;
    } else if(data.success){
      const r = data.result;
      resultDiv.style.display='block';
      resultDiv.innerHTML = `
        <h3>Results</h3>
        <p><strong>Possible disease detected:</strong> ${r.disease}</p>
        <p><strong>Health score:</strong> ${r.health_score} / 100</p>
        <p><strong>Confidence:</strong> ${r.confidence}</p>
        <p><strong>Suggested next step:</strong> ${r.suggestion}</p>
      `;
    } else {
      resultDiv.style.display='block';
      resultDiv.textContent = 'Unexpected response from server.';
    }
  });
});
