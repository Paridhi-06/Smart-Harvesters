
from flask import Flask, render_template, request, jsonify, send_from_directory, abort
from werkzeug.utils import secure_filename
import os, logging, traceback, yaml
from model import ModelWrapper
from utils import allowed_file

with open('config.yaml') as fh:
    cfg = yaml.safe_load(fh)

UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger('cropguardian')

app = Flask(__name__, static_folder='static', template_folder='templates')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024  # 8 MB max upload

MODEL = ModelWrapper(cfg['model']['path'], input_size=cfg['model'].get('input_size',224))
logger.info('Model wrapper initialized.')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/problem')
def problem():
    return render_template('problem.html')

@app.route('/how-it-works')
def how_it_works():
    return render_template('how_it_works.html')

@app.route('/hardware')
def hardware():
    return render_template('hardware.html')

@app.route('/detection')
def detection():
    return render_template('detection.html')

@app.route('/demo')
def demo():
    return render_template('demo.html')

@app.route('/api/predict', methods=['POST'])
def api_predict():
    try:
        if 'image' not in request.files:
            return jsonify({'error':'no image part'}), 400
        file = request.files['image']
        if file.filename == '' or not allowed_file(file.filename):
            return jsonify({'error':'invalid filename or unsupported file type'}), 400
        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(save_path)
        logger.info('Saved uploaded file: %s', save_path)

        pred = MODEL.predict(save_path)
        logger.info('Prediction result: %s', pred)
        return jsonify({'success': True, 'result': pred})
    except Exception as e:
        logger.error('Prediction error: %s', traceback.format_exc())
        return jsonify({'error': 'internal server error'}), 500

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host=cfg['server']['host'], port=cfg['server']['port'], debug=cfg['server']['debug'])
